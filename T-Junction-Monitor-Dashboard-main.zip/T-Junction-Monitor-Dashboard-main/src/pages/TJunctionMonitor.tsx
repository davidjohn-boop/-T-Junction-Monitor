import React, { useEffect, useState } from 'react';
import { Moon, Sun, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Dashboard } from '../components/Dashboard';
import { Analytics } from '../components/Analytics';
import { History } from '../components/History';
import { Settings } from '../components/Settings';
import { useTrafficData } from '../hooks/useTrafficData';
type Section = 'dashboard' | 'analytics' | 'history' | 'settings';
export function TJunctionMonitor() {
  const [activeSection, setActiveSection] = useState<Section>('dashboard');
  const [darkMode, setDarkMode] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const {
    trafficData,
    analyticsData,
    history,
    connectionStatus,
    loading,
    error,
    isConnected,
    savedSettings,
    serverAvailable,
    connect,
    disconnect,
    clearSavedSettings,
    refreshData,
    refreshAll
  } = useTrafficData();
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);
  const sections = [{
    id: 'dashboard' as Section,
    label: 'Dashboard'
  }, {
    id: 'analytics' as Section,
    label: 'Analytics'
  }, {
    id: 'history' as Section,
    label: 'History'
  }, {
    id: 'settings' as Section,
    label: 'Settings'
  }];
  return <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <motion.header initial={{
      y: -100
    }} animate={{
      y: 0
    }} className="glass-strong border-b border-slate-700/50 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <motion.div whileHover={{
              rotate: 180
            }} transition={{
              duration: 0.3
            }} className="w-10 h-10 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-500 rounded-lg flex items-center justify-center glow-blue">
                <span className="text-white font-bold text-xl">T</span>
              </motion.div>
              <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                T-Junction Monitor
              </h1>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-slate-400">
                <Clock className="w-4 h-4" />
                <span>{currentTime.toLocaleTimeString()}</span>
              </div>

              {isConnected && <motion.div initial={{
              scale: 0
            }} animate={{
              scale: 1
            }} className="flex items-center gap-2 px-3 py-1.5 glass rounded-full">
                  <motion.div animate={{
                scale: [1, 1.2, 1]
              }} transition={{
                duration: 2,
                repeat: Infinity
              }} className="w-2 h-2 bg-blue-500 rounded-full" />
                  <span className="text-xs text-slate-400">Connected</span>
                </motion.div>}

              <motion.button whileHover={{
              scale: 1.1
            }} whileTap={{
              scale: 0.9
            }} onClick={() => setDarkMode(!darkMode)} className="p-2 hover:bg-slate-800/50 rounded-lg transition-colors" aria-label="Toggle theme">
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </motion.button>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Navigation */}
      <nav className="glass border-b border-slate-700/50 sticky top-16 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1 overflow-x-auto">
            {sections.map(section => <motion.button key={section.id} onClick={() => setActiveSection(section.id)} whileHover={{
            y: -2
          }} whileTap={{
            y: 0
          }} className={`relative px-6 py-3 font-medium transition-colors whitespace-nowrap ${activeSection === section.id ? 'text-white' : 'text-slate-400 hover:text-white'}`}>
                {section.label}
                {activeSection === section.id && <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-blue-500 to-cyan-500" transition={{
              type: 'spring',
              stiffness: 380,
              damping: 30
            }} />}
              </motion.button>)}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {error && <motion.div initial={{
          opacity: 0,
          y: -20
        }} animate={{
          opacity: 1,
          y: 0
        }} exit={{
          opacity: 0,
          y: -20
        }} className="mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400 flex items-center gap-3">
              <div className="w-2 h-2 bg-red-500 rounded-full" />
              {error}
            </motion.div>}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          <motion.div key={activeSection} initial={{
          opacity: 0,
          x: 20
        }} animate={{
          opacity: 1,
          x: 0
        }} exit={{
          opacity: 0,
          x: -20
        }} transition={{
          duration: 0.3
        }}>
            {activeSection === 'dashboard' && <Dashboard data={trafficData} loading={loading} onRefresh={refreshAll} isConnected={isConnected} />}
            {activeSection === 'analytics' && <Analytics data={analyticsData} isConnected={isConnected} />}
            {activeSection === 'history' && <History data={history} isConnected={isConnected} />}
            {activeSection === 'settings' && <Settings status={connectionStatus} onConnect={connect} onDisconnect={disconnect} onClearSettings={clearSavedSettings} loading={loading} isConnected={isConnected} savedSettings={savedSettings} serverAvailable={serverAvailable} />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <motion.footer initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} transition={{
      delay: 0.5
    }} className="glass-strong border-t border-slate-700/50 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-400">
              T-Junction Monitor v1.0.0 | Traffic Management System
            </p>
            <p className="text-sm text-slate-500">
              Built with React + TypeScript + Tailwind CSS
            </p>
          </div>
        </div>
      </motion.footer>
    </div>;
}
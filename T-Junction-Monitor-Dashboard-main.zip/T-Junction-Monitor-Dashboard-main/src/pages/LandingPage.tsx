import React from 'react';
import { ArrowRight, Activity, BarChart3, History, Settings, Wifi, MapPin, Zap, Shield, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';
interface LandingPageProps {
  onEnterApp: () => void;
}
export function LandingPage({
  onEnterApp
}: LandingPageProps) {
  const features = [{
    icon: <Activity className="w-6 h-6" />,
    title: 'Real-Time Monitoring',
    description: 'Live traffic light status and queue monitoring with instant updates'
  }, {
    icon: <BarChart3 className="w-6 h-6" />,
    title: 'Advanced Analytics',
    description: 'Comprehensive traffic insights with visual charts and metrics'
  }, {
    icon: <History className="w-6 h-6" />,
    title: 'Historical Data',
    description: 'Track traffic patterns over time with detailed history logs'
  }, {
    icon: <Wifi className="w-6 h-6" />,
    title: 'Wi-Fi Integration',
    description: 'Seamless ESP32 device connection with network scanning'
  }, {
    icon: <MapPin className="w-6 h-6" />,
    title: 'Location Mapping',
    description: 'Visual junction location with interactive map interface'
  }, {
    icon: <Settings className="w-6 h-6" />,
    title: 'Easy Configuration',
    description: 'Simple setup process with intuitive device management'
  }];
  const stats = [{
    icon: <Zap className="w-5 h-5" />,
    value: '< 100ms',
    label: 'Response Time'
  }, {
    icon: <Shield className="w-5 h-5" />,
    value: '99.9%',
    label: 'Uptime'
  }, {
    icon: <TrendingUp className="w-5 h-5" />,
    value: '24/7',
    label: 'Monitoring'
  }];
  return <div className="min-h-screen bg-slate-950 text-white overflow-hidden relative">
      {/* Background Image with Overlay */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{
        backgroundImage: `url('https://images.unsplash.com/photo-1519003722824-194d4455a60c?q=80&w=2000')`
      }} />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-950/95 to-blue-950/90" />

        {/* Animated gradient orbs */}
        <motion.div animate={{
        scale: [1, 1.2, 1],
        opacity: [0.3, 0.5, 0.3]
      }} transition={{
        duration: 8,
        repeat: Infinity
      }} className="absolute top-1/4 -left-1/4 w-96 h-96 bg-blue-500/30 rounded-full blur-3xl" />
        <motion.div animate={{
        scale: [1, 1.3, 1],
        opacity: [0.2, 0.4, 0.2]
      }} transition={{
        duration: 10,
        repeat: Infinity
      }} className="absolute bottom-1/4 -right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Hero Section */}
        <div className="relative">
          {/* Grid overlay */}
          <div className="absolute inset-0 opacity-5" style={{
          backgroundImage: `
                linear-gradient(to right, rgb(59, 130, 246) 1px, transparent 1px),
                linear-gradient(to bottom, rgb(59, 130, 246) 1px, transparent 1px)
              `,
          backgroundSize: '60px 60px'
        }} />

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32">
            {/* Logo */}
            <motion.div initial={{
            opacity: 0,
            y: -20
          }} animate={{
            opacity: 1,
            y: 0
          }} className="flex items-center gap-3 mb-16">
              <motion.div whileHover={{
              rotate: 360
            }} transition={{
              duration: 0.6
            }} className="w-12 h-12 bg-gradient-to-br from-blue-500 via-blue-600 to-cyan-500 rounded-xl flex items-center justify-center glow-blue-strong shadow-2xl">
                <span className="text-white font-bold text-2xl">T</span>
              </motion.div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                T-Junction Monitor
              </span>
            </motion.div>

            {/* Hero content */}
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <motion.div initial={{
                opacity: 0,
                y: 20
              }} animate={{
                opacity: 1,
                y: 0
              }} transition={{
                delay: 0.1
              }}>
                  <motion.div initial={{
                  opacity: 0,
                  scale: 0.9
                }} animate={{
                  opacity: 1,
                  scale: 1
                }} transition={{
                  delay: 0.2
                }} className="inline-flex items-center gap-2 px-4 py-2 glass rounded-full mb-6">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    <span className="text-sm text-slate-300">
                      Live Traffic Intelligence
                    </span>
                  </motion.div>

                  <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                    Smart Traffic
                    <br />
                    <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
                      Monitoring System
                    </span>
                  </h1>
                  <p className="text-xl text-slate-400 mb-8 leading-relaxed">
                    Real-time traffic junction monitoring with advanced
                    analytics, ESP32 integration, and intuitive visualization.
                    Monitor, analyze, and optimize traffic flow.
                  </p>

                  {/* Stats */}
                  <div className="flex flex-wrap gap-6 mb-8">
                    {stats.map((stat, index) => <motion.div key={stat.label} initial={{
                    opacity: 0,
                    y: 20
                  }} animate={{
                    opacity: 1,
                    y: 0
                  }} transition={{
                    delay: 0.3 + index * 0.1
                  }} className="flex items-center gap-3">
                        <div className="w-10 h-10 glass rounded-lg flex items-center justify-center text-blue-400">
                          {stat.icon}
                        </div>
                        <div>
                          <p className="text-lg font-bold text-white">
                            {stat.value}
                          </p>
                          <p className="text-xs text-slate-500">{stat.label}</p>
                        </div>
                      </motion.div>)}
                  </div>

                  <motion.button initial={{
                  opacity: 0,
                  y: 20
                }} animate={{
                  opacity: 1,
                  y: 0
                }} transition={{
                  delay: 0.4
                }} whileHover={{
                  scale: 1.05,
                  boxShadow: '0 0 40px rgba(59, 130, 246, 0.6)'
                }} whileTap={{
                  scale: 0.95
                }} onClick={onEnterApp} className="flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 rounded-xl font-medium text-lg transition-all glow-blue-strong group shadow-2xl">
                    Launch Monitor
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </motion.button>
                </motion.div>
              </div>

              {/* Hero visual */}
              <motion.div initial={{
              opacity: 0,
              scale: 0.9
            }} animate={{
              opacity: 1,
              scale: 1
            }} transition={{
              delay: 0.2
            }} className="relative">
                <div className="glass-strong rounded-2xl p-8 relative overflow-hidden shadow-2xl">
                  {/* Animated background */}
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10" />

                  {/* Mock dashboard preview */}
                  <div className="relative space-y-4">
                    <div className="flex items-center justify-between">
                      <motion.div animate={{
                      opacity: [0.5, 1, 0.5]
                    }} transition={{
                      duration: 2,
                      repeat: Infinity
                    }} className="h-3 w-24 bg-blue-500/50 rounded" />
                      <motion.div animate={{
                      opacity: [0.5, 1, 0.5]
                    }} transition={{
                      duration: 2,
                      delay: 0.5,
                      repeat: Infinity
                    }} className="h-3 w-16 bg-cyan-500/50 rounded" />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      {[1, 2, 3].map(i => <motion.div key={i} animate={{
                      opacity: [0.3, 0.7, 0.3],
                      y: [0, -5, 0]
                    }} transition={{
                      duration: 2,
                      delay: i * 0.2,
                      repeat: Infinity
                    }} className="glass rounded-lg p-4 h-24">
                          <div className="h-2 w-12 bg-blue-400/30 rounded mb-2" />
                          <div className="h-6 w-16 bg-blue-400/50 rounded" />
                        </motion.div>)}
                    </div>

                    <motion.div animate={{
                    opacity: [0.4, 0.8, 0.4]
                  }} transition={{
                    duration: 3,
                    repeat: Infinity
                  }} className="glass rounded-lg p-4 h-32">
                      <div className="flex items-end justify-between h-full gap-2">
                        {[40, 70, 50, 90, 60, 80].map((height, i) => <motion.div key={i} animate={{
                        height: [`${height * 0.5}%`, `${height}%`, `${height * 0.5}%`]
                      }} transition={{
                        duration: 2,
                        delay: i * 0.1,
                        repeat: Infinity
                      }} className="flex-1 bg-gradient-to-t from-blue-500 to-cyan-500 rounded-t" />)}
                      </div>
                    </motion.div>

                    <div className="flex gap-4">
                      <motion.div animate={{
                      opacity: [0.3, 0.6, 0.3]
                    }} transition={{
                      duration: 2.5,
                      repeat: Infinity
                    }} className="flex-1 glass rounded-lg p-4 h-20" />
                      <motion.div animate={{
                      opacity: [0.3, 0.6, 0.3]
                    }} transition={{
                      duration: 2.5,
                      delay: 0.5,
                      repeat: Infinity
                    }} className="flex-1 glass rounded-lg p-4 h-20" />
                    </div>
                  </div>
                </div>

                {/* Floating elements */}
                <motion.div animate={{
                y: [0, -20, 0],
                rotate: [0, 5, 0]
              }} transition={{
                duration: 4,
                repeat: Infinity
              }} className="absolute -top-4 -right-4 w-24 h-24 bg-blue-500/30 rounded-full blur-2xl" />
                <motion.div animate={{
                y: [0, 20, 0],
                rotate: [0, -5, 0]
              }} transition={{
                duration: 5,
                repeat: Infinity
              }} className="absolute -bottom-4 -left-4 w-32 h-32 bg-cyan-500/30 rounded-full blur-2xl" />
              </motion.div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="relative py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} viewport={{
            once: true
          }} className="text-center mb-16">
              <h2 className="text-4xl font-bold mb-4">Powerful Features</h2>
              <p className="text-xl text-slate-400">
                Everything you need for comprehensive traffic monitoring
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature, index) => <motion.div key={feature.title} initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} viewport={{
              once: true
            }} transition={{
              delay: index * 0.1
            }} whileHover={{
              y: -5
            }} className="glass-strong rounded-xl p-6 hover:bg-slate-800/50 transition-all group cursor-pointer">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4 text-blue-400 group-hover:scale-110 group-hover:bg-blue-500/30 transition-all">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400">{feature.description}</p>
                </motion.div>)}
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="relative py-24">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{
            opacity: 0,
            scale: 0.9
          }} whileInView={{
            opacity: 1,
            scale: 1
          }} viewport={{
            once: true
          }} className="glass-strong rounded-2xl p-12 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10" />
              <div className="relative">
                <h2 className="text-4xl font-bold mb-4">
                  Ready to Start Monitoring?
                </h2>
                <p className="text-xl text-slate-400 mb-8">
                  Connect your ESP32 device and start tracking traffic in
                  real-time
                </p>
                <motion.button whileHover={{
                scale: 1.05,
                boxShadow: '0 0 40px rgba(59, 130, 246, 0.6)'
              }} whileTap={{
                scale: 0.95
              }} onClick={onEnterApp} className="px-8 py-4 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 rounded-xl font-medium text-lg transition-all glow-blue-strong shadow-2xl">
                  Get Started Now
                </motion.button>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Footer */}
        <footer className="glass-strong border-t border-slate-700/50 py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <p className="text-sm text-slate-400">
                T-Junction Monitor v1.0.0 | Traffic Management System
              </p>
              <p className="text-sm text-slate-500">
                Built with React + TypeScript + Tailwind CSS
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>;
}
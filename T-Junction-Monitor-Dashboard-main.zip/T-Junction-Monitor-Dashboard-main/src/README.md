
# T-Junction Traffic Monitor

A real-time traffic monitoring system for T-junction intersections with ESP32 integration.

## Quick Start

### 1. Start the Backend Server

The Express server must be running first:

```bash
cd server
npm install
node index.js
```

You should see:
```
T-Junction Monitor Server running on http://localhost:3001
```

### 2. Start the React App

In a separate terminal:

```bash
npm install
npm start
```

The app will open at http://localhost:3000

### 3. Connect to Your Device

1. Go to the **Settings** tab
2. Enter your WiFi network details
3. Enter your ESP32 device IP and port
4. Click **Connect**

## Troubleshooting

### "Failed to fetch" Error

**Problem:** The React app can't connect to the backend server.

**Solution:** Make sure the Express server is running on port 3001:
```bash
cd server
node index.js
```

### Port Already in Use

If port 3001 is already in use, you can change it in `server/index.js`:
```javascript
const PORT = 3001; // Change this to another port
```

Then update the API_BASE in `hooks/useTrafficData.ts` and `hooks/useNetworkScanner.ts` to match.

### No Networks Found

The network scanner shows simulated networks for demo purposes. To connect to your actual network, manually enter the SSID in the connection form.

## Architecture

- **Frontend:** React + TypeScript + Tailwind CSS + Framer Motion
- **Backend:** Express.js (REST API)
- **Hardware:** ESP32 (sends traffic data via POST /api/traffic)

## API Endpoints

- `GET /api/traffic` - Current traffic data
- `POST /api/traffic` - Update traffic data (from ESP32)
- `GET /api/analytics` - Analytics data
- `GET /api/history` - Traffic history
- `GET /api/status` - Connection status
- `POST /api/connect` - Configure WiFi settings
- `GET /api/scan-networks` - Scan available networks

## Development

The server generates sample data every 5 seconds for testing without hardware.

To receive real data from ESP32, configure your device to POST to:
```
http://YOUR_COMPUTER_IP:3001/api/traffic
```

With JSON body:
```json
{
  "mainQueue": 5,
  "sideQueue": 3,
  "mainLight": "green",
  "sideLight": "red",
  "totalVehiclesToday": 150
}
```

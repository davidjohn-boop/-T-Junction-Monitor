import { useState, useCallback } from 'react';
export interface WiFiNetwork {
  ssid: string;
  signal: number; // 0-100
  secured: boolean;
  channel: number;
}
const API_BASE = 'http://localhost:3001/api';
export function useNetworkScanner() {
  const [networks, setNetworks] = useState<WiFiNetwork[]>([]);
  const [scanning, setScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scanNetworks = useCallback(async () => {
    try {
      setScanning(true);
      setError(null);
      const response = await fetch(`${API_BASE}/scan-networks`);
      if (!response.ok) throw new Error('Failed to scan networks');
      const data = await response.json();
      setNetworks(data.networks);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Scan failed');
      // Fallback to mock data if backend not available
      setNetworks([{
        ssid: 'TrafficNet-5G',
        signal: 95,
        secured: true,
        channel: 36
      }, {
        ssid: 'CityWiFi-Public',
        signal: 82,
        secured: false,
        channel: 6
      }, {
        ssid: 'Junction-Monitor',
        signal: 78,
        secured: true,
        channel: 11
      }, {
        ssid: 'SmartCity-IoT',
        signal: 65,
        secured: true,
        channel: 1
      }, {
        ssid: 'ESP32-Traffic',
        signal: 58,
        secured: true,
        channel: 44
      }]);
    } finally {
      setScanning(false);
    }
  }, []);
  return {
    networks,
    scanning,
    error,
    scanNetworks
  };
}
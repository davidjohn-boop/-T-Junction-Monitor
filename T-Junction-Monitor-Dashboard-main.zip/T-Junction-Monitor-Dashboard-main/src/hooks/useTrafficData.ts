import { useState, useCallback, useEffect } from 'react';
import { TrafficData, AnalyticsData, HistoryEntry, ConnectionStatus, WiFiSettings } from '../types/traffic';
const API_BASE = 'http://localhost:3001/api';
const STORAGE_KEY = 'tjunction_wifi_settings';

// Add server health check
async function checkServerHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE}/status`, {
      method: 'GET',
      signal: AbortSignal.timeout(3000) // 3 second timeout
    });
    return response.ok;
  } catch {
    return false;
  }
}
export function useTrafficData() {
  const [trafficData, setTrafficData] = useState<TrafficData | null>(null);
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({
    connected: false,
    uptime: '0h 0m',
    lastUpdate: 'Never'
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [savedSettings, setSavedSettings] = useState<WiFiSettings | null>(null);
  const [serverAvailable, setServerAvailable] = useState<boolean | null>(null);

  // Check server availability on mount
  useEffect(() => {
    checkServerHealth().then(setServerAvailable);
  }, []);

  // Load saved settings on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const settings = JSON.parse(saved);
        setSavedSettings(settings);
      } catch (err) {
        console.error('Failed to load saved settings:', err);
      }
    }
  }, []);
  const fetchTrafficData = useCallback(async () => {
    if (!isConnected) return;
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`${API_BASE}/traffic`);
      if (!response.ok) throw new Error('Failed to fetch traffic data');
      const data = await response.json();
      setTrafficData(data);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(`Unable to fetch data: ${errorMessage}`);
    } finally {
      setLoading(false);
    }
  }, [isConnected]);
  const fetchAnalytics = useCallback(async () => {
    if (!isConnected) return;
    try {
      const response = await fetch(`${API_BASE}/analytics`);
      if (!response.ok) throw new Error('Failed to fetch analytics');
      const data = await response.json();
      setAnalyticsData(data);
    } catch (err) {
      console.error('Analytics fetch error:', err);
    }
  }, [isConnected]);
  const fetchHistory = useCallback(async () => {
    if (!isConnected) return;
    try {
      const response = await fetch(`${API_BASE}/history`);
      if (!response.ok) throw new Error('Failed to fetch history');
      const data = await response.json();
      setHistory(data);
    } catch (err) {
      console.error('History fetch error:', err);
    }
  }, [isConnected]);
  const fetchConnectionStatus = useCallback(async () => {
    if (!isConnected) return;
    try {
      const response = await fetch(`${API_BASE}/status`);
      if (!response.ok) throw new Error('Failed to fetch status');
      const data = await response.json();
      setConnectionStatus(data);
    } catch (err) {
      console.error('Status fetch error:', err);
    }
  }, [isConnected]);
  const connect = useCallback(async (settings: WiFiSettings, rememberSettings: boolean = false) => {
    try {
      setLoading(true);
      setError(null);

      // Check if server is available first
      const serverOk = await checkServerHealth();
      if (!serverOk) {
        throw new Error('Cannot connect to server. Make sure the Express server is running on port 3001. Run: cd server && node index.js');
      }
      const response = await fetch(`${API_BASE}/connect`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settings)
      });
      if (!response.ok) throw new Error('Failed to connect');

      // Save settings if requested
      if (rememberSettings) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
        setSavedSettings(settings);
      }
      setIsConnected(true);
      setServerAvailable(true);
      await fetchConnectionStatus();
      await fetchTrafficData();
      await fetchAnalytics();
      await fetchHistory();
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Connection failed';
      setError(errorMessage);
      setServerAvailable(false);
      return false;
    } finally {
      setLoading(false);
    }
  }, [fetchConnectionStatus, fetchTrafficData, fetchAnalytics, fetchHistory]);
  const disconnect = useCallback(() => {
    setIsConnected(false);
    setConnectionStatus({
      connected: false,
      uptime: '0h 0m',
      lastUpdate: 'Never'
    });
    setTrafficData(null);
    setAnalyticsData(null);
    setHistory([]);
  }, []);
  const clearSavedSettings = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setSavedSettings(null);
  }, []);
  const refreshAll = useCallback(async () => {
    if (!isConnected) return;
    await Promise.all([fetchTrafficData(), fetchAnalytics(), fetchHistory(), fetchConnectionStatus()]);
  }, [isConnected, fetchTrafficData, fetchAnalytics, fetchHistory, fetchConnectionStatus]);
  return {
    trafficData,
    analyticsData,
    history,
    connectionStatus,
    loading,
    error,
    isConnected,
    savedSettings,
    serverAvailable,
    connect,
    disconnect,
    clearSavedSettings,
    refreshData: fetchTrafficData,
    refreshAll
  };
}
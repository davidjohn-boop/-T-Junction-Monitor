import React, { useState } from 'react';
import { LandingPage } from './pages/LandingPage';
import { TJunctionMonitor } from './pages/TJunctionMonitor';
export function App() {
  const [showApp, setShowApp] = useState(false);
  if (!showApp) {
    return <LandingPage onEnterApp={() => setShowApp(true)} />;
  }
  return <TJunctionMonitor />;
}
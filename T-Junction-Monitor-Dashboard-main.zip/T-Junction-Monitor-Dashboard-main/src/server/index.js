const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3001;
app.use(cors());
app.use(express.json());

// In-memory data store
let trafficData = {
  mainQueue: 0,
  sideQueue: 0,
  mainLight: 'red',
  sideLight: 'green',
  totalVehiclesToday: 0,
  timestamp: new Date().toISOString()
};
let analyticsData = {
  totalVehicles: 0,
  avgQueueLength: 0,
  peakCongestion: 0,
  signalCycles: 0,
  queueHistory: [],
  eventLog: []
};
let historyData = [];
let connectionStatus = {
  connected: false,
  uptime: '0h 0m',
  lastUpdate: 'Never'
};
let wifiSettings = null;
let serverStartTime = Date.now();

// Mock available networks
const availableNetworks = [{
  ssid: 'TrafficNet-5G',
  signal: 95,
  secured: true,
  channel: 36
}, {
  ssid: 'CityWiFi-Public',
  signal: 82,
  secured: false,
  channel: 6
}, {
  ssid: 'Junction-Monitor',
  signal: 78,
  secured: true,
  channel: 11
}, {
  ssid: 'SmartCity-IoT',
  signal: 65,
  secured: true,
  channel: 1
}, {
  ssid: 'ESP32-Traffic',
  signal: 58,
  secured: true,
  channel: 44
}, {
  ssid: 'Traffic-Control-A',
  signal: 45,
  secured: true,
  channel: 149
}];

// Helper function to generate sample data
function generateSampleData() {
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });

  // Update traffic data
  trafficData.mainQueue = Math.floor(Math.random() * 15);
  trafficData.sideQueue = Math.floor(Math.random() * 10);
  trafficData.mainLight = ['red', 'yellow', 'green'][Math.floor(Math.random() * 3)];
  trafficData.sideLight = trafficData.mainLight === 'green' ? 'red' : 'green';
  trafficData.totalVehiclesToday += Math.floor(Math.random() * 5);
  trafficData.timestamp = now.toISOString();

  // Update analytics
  analyticsData.totalVehicles = trafficData.totalVehiclesToday;
  analyticsData.signalCycles += 1;
  const currentAvg = (trafficData.mainQueue + trafficData.sideQueue) / 2;
  analyticsData.avgQueueLength = (analyticsData.avgQueueLength + currentAvg) / 2;
  analyticsData.peakCongestion = Math.max(analyticsData.peakCongestion, trafficData.mainQueue, trafficData.sideQueue);

  // Add to queue history
  analyticsData.queueHistory.push({
    time: timeStr,
    mainQueue: trafficData.mainQueue,
    sideQueue: trafficData.sideQueue,
    vehiclesPassed: Math.floor(Math.random() * 10)
  });
  if (analyticsData.queueHistory.length > 20) {
    analyticsData.queueHistory.shift();
  }

  // Add event log entry occasionally
  if (Math.random() > 0.7) {
    const events = [{
      event: 'Traffic light cycle completed',
      severity: 'info'
    }, {
      event: 'High congestion detected on main road',
      severity: 'warning'
    }, {
      event: 'Normal traffic flow resumed',
      severity: 'info'
    }, {
      event: 'Signal timing adjusted',
      severity: 'info'
    }];
    const randomEvent = events[Math.floor(Math.random() * events.length)];
    analyticsData.eventLog.unshift({
      id: Date.now().toString(),
      timestamp: now.toLocaleString(),
      ...randomEvent
    });
    if (analyticsData.eventLog.length > 10) {
      analyticsData.eventLog.pop();
    }
  }

  // Add to history
  historyData.unshift({
    time: now.toLocaleString(),
    mainQueue: trafficData.mainQueue,
    sideQueue: trafficData.sideQueue
  });
  if (historyData.length > 50) {
    historyData.pop();
  }

  // Update connection status if connected
  if (connectionStatus.connected) {
    const uptime = Date.now() - serverStartTime;
    const hours = Math.floor(uptime / (1000 * 60 * 60));
    const minutes = Math.floor(uptime % (1000 * 60 * 60) / (1000 * 60));
    connectionStatus.uptime = `${hours}h ${minutes}m`;
    connectionStatus.lastUpdate = now.toLocaleString();
  }
}

// Generate sample data every 5 seconds
setInterval(generateSampleData, 5000);

// Initialize with some data
generateSampleData();

// Routes
app.get('/api/traffic', (req, res) => {
  res.json(trafficData);
});
app.post('/api/traffic', (req, res) => {
  const {
    mainQueue,
    sideQueue,
    mainLight,
    sideLight,
    totalVehiclesToday
  } = req.body;
  if (mainQueue !== undefined) trafficData.mainQueue = mainQueue;
  if (sideQueue !== undefined) trafficData.sideQueue = sideQueue;
  if (mainLight) trafficData.mainLight = mainLight;
  if (sideLight) trafficData.sideLight = sideLight;
  if (totalVehiclesToday !== undefined) trafficData.totalVehiclesToday = totalVehiclesToday;
  trafficData.timestamp = new Date().toISOString();
  res.json({
    success: true,
    data: trafficData
  });
});
app.get('/api/analytics', (req, res) => {
  res.json(analyticsData);
});
app.get('/api/history', (req, res) => {
  res.json(historyData);
});
app.get('/api/status', (req, res) => {
  res.json(connectionStatus);
});
app.post('/api/connect', (req, res) => {
  const {
    ssid,
    password,
    deviceIp,
    port
  } = req.body;
  if (!ssid || !password || !deviceIp || !port) {
    return res.status(400).json({
      success: false,
      error: 'Missing required fields'
    });
  }
  wifiSettings = {
    ssid,
    password,
    deviceIp,
    port
  };
  connectionStatus.connected = true;
  connectionStatus.lastUpdate = new Date().toLocaleString();
  serverStartTime = Date.now();
  console.log('Wi-Fi connection configured:', {
    ssid,
    deviceIp,
    port
  });
  res.json({
    success: true,
    message: 'Connected successfully',
    status: connectionStatus
  });
});
app.get('/api/scan-networks', (req, res) => {
  // Simulate network scan with slight randomization
  const networks = availableNetworks.map(network => ({
    ...network,
    signal: Math.max(20, Math.min(100, network.signal + Math.floor(Math.random() * 10 - 5)))
  }));
  res.json({
    success: true,
    networks: networks.sort((a, b) => b.signal - a.signal)
  });
});
app.listen(PORT, () => {
  console.log(`T-Junction Monitor Server running on http://localhost:${PORT}`);
  console.log('\nAvailable endpoints:');
  console.log('  GET  /api/traffic        - Get current traffic data');
  console.log('  POST /api/traffic        - Update traffic data (from ESP32)');
  console.log('  GET  /api/analytics      - Get analytics data');
  console.log('  GET  /api/history        - Get traffic history');
  console.log('  GET  /api/status         - Get connection status');
  console.log('  POST /api/connect        - Configure Wi-Fi settings');
  console.log('  GET  /api/scan-networks  - Scan available Wi-Fi networks');
  console.log('\nServer is generating sample data every 5 seconds');
  console.log('Ready to receive real data from ESP32 via POST /api/traffic');
});
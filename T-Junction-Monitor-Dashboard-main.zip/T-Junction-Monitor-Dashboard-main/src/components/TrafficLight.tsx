import React from 'react';
import { motion } from 'framer-motion';
interface TrafficLightProps {
  state: 'red' | 'yellow' | 'green';
  label: string;
}
export function TrafficLight({
  state,
  label
}: TrafficLightProps) {
  return <div className="flex flex-col items-center gap-3">
      <div className="glass-strong rounded-xl p-4">
        <div className="flex flex-col gap-3">
          <motion.div animate={{
          scale: state === 'red' ? [1, 1.1, 1] : 1,
          opacity: state === 'red' ? 1 : 0.2
        }} transition={{
          duration: 0.5,
          repeat: state === 'red' ? Infinity : 0,
          repeatDelay: 1
        }} className={`w-10 h-10 rounded-full transition-all duration-300 ${state === 'red' ? 'bg-red-500 shadow-[0_0_25px_rgba(239,68,68,0.8)]' : 'bg-red-950'}`} />
          <motion.div animate={{
          scale: state === 'yellow' ? [1, 1.1, 1] : 1,
          opacity: state === 'yellow' ? 1 : 0.2
        }} transition={{
          duration: 0.5,
          repeat: state === 'yellow' ? Infinity : 0,
          repeatDelay: 1
        }} className={`w-10 h-10 rounded-full transition-all duration-300 ${state === 'yellow' ? 'bg-yellow-400 shadow-[0_0_25px_rgba(250,204,21,0.8)]' : 'bg-yellow-950'}`} />
          <motion.div animate={{
          scale: state === 'green' ? [1, 1.1, 1] : 1,
          opacity: state === 'green' ? 1 : 0.2
        }} transition={{
          duration: 0.5,
          repeat: state === 'green' ? Infinity : 0,
          repeatDelay: 1
        }} className={`w-10 h-10 rounded-full transition-all duration-300 ${state === 'green' ? 'bg-green-500 shadow-[0_0_25px_rgba(34,197,94,0.8)]' : 'bg-green-950'}`} />
        </div>
      </div>
      <span className="text-sm font-medium text-slate-300">{label}</span>
    </div>;
}
import React from 'react';
import { motion } from 'framer-motion';
interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  delay?: number;
}
export function StatsCard({
  title,
  value,
  icon,
  trend,
  delay = 0
}: StatsCardProps) {
  return <motion.div initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.5,
    delay
  }} className="glass rounded-xl p-6 hover:bg-slate-800/50 transition-all duration-300">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-slate-400 text-sm font-medium mb-2">{title}</p>
          <motion.p initial={{
          scale: 0.8
        }} animate={{
          scale: 1
        }} transition={{
          duration: 0.3,
          delay: delay + 0.2
        }} className="text-4xl font-bold text-white mb-1">
            {value}
          </motion.p>
          {trend && <p className="text-sm text-slate-500">{trend}</p>}
        </div>
        <div className="text-blue-400 ml-4">{icon}</div>
      </div>
    </motion.div>;
}
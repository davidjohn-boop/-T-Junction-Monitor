import React from 'react';
import { Car, TrendingUp, AlertCircle, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import { StatsCard } from './StatsCard';
import { AnalyticsData } from '../types/traffic';
interface AnalyticsProps {
  data: AnalyticsData | null;
  isConnected: boolean;
}
export function Analytics({
  data,
  isConnected
}: AnalyticsProps) {
  const maxQueue = Math.max(...(data?.queueHistory.map(d => Math.max(d.mainQueue, d.sideQueue)) || [10]));
  if (!isConnected) {
    return <motion.div initial={{
      opacity: 0,
      scale: 0.95
    }} animate={{
      opacity: 1,
      scale: 1
    }} className="glass-strong rounded-xl p-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Activity className="w-8 h-8 text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">
            No Analytics Available
          </h3>
          <p className="text-slate-400">
            Connect to the device to view traffic analytics and insights.
          </p>
        </div>
      </motion.div>;
  }
  return <div className="space-y-6">
      <motion.h2 initial={{
      opacity: 0,
      x: -20
    }} animate={{
      opacity: 1,
      x: 0
    }} className="text-2xl font-bold text-white">
        Traffic Analytics
      </motion.h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard title="Total Vehicles" value={data?.totalVehicles || 0} icon={<Car className="w-8 h-8" />} trend="Today" delay={0} />
        <StatsCard title="Avg Queue Length" value={data?.avgQueueLength.toFixed(1) || '0.0'} icon={<TrendingUp className="w-8 h-8" />} trend="vehicles" delay={0.1} />
        <StatsCard title="Peak Congestion" value={data?.peakCongestion || 0} icon={<AlertCircle className="w-8 h-8" />} trend="vehicles" delay={0.2} />
        <StatsCard title="Signal Cycles" value={data?.signalCycles || 0} icon={<Activity className="w-8 h-8" />} trend="Today" delay={0.3} />
      </div>

      <motion.div initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      delay: 0.4
    }} className="glass-strong rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">
          Queue Length & Vehicles Passed
        </h3>
        <div className="h-64 flex items-end justify-between gap-2">
          {data?.queueHistory.slice(-12).map((point, index) => {
          const mainHeight = point.mainQueue / maxQueue * 100;
          const sideHeight = point.sideQueue / maxQueue * 100;
          return <motion.div key={index} initial={{
            opacity: 0,
            scaleY: 0
          }} animate={{
            opacity: 1,
            scaleY: 1
          }} transition={{
            delay: 0.5 + index * 0.05,
            duration: 0.3
          }} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex gap-1 items-end h-48">
                  <div className="flex-1 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t transition-all duration-300" style={{
                height: `${mainHeight}%`
              }} title={`Main: ${point.mainQueue}`} />
                  <div className="flex-1 bg-gradient-to-t from-cyan-600 to-cyan-400 rounded-t transition-all duration-300" style={{
                height: `${sideHeight}%`
              }} title={`Side: ${point.sideQueue}`} />
                </div>
                <span className="text-xs text-slate-500">{point.time}</span>
              </motion.div>;
        })}
        </div>
        <div className="flex items-center justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gradient-to-br from-blue-600 to-blue-400 rounded" />
            <span className="text-sm text-slate-400">Main Road</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gradient-to-br from-cyan-600 to-cyan-400 rounded" />
            <span className="text-sm text-slate-400">Side Road</span>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      delay: 0.6
    }} className="glass-strong rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Event Log</h3>
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {data?.eventLog.map((event, index) => <motion.div key={event.id} initial={{
          opacity: 0,
          x: -20
        }} animate={{
          opacity: 1,
          x: 0
        }} transition={{
          delay: 0.7 + index * 0.05
        }} className="flex items-start gap-3 p-3 glass rounded-lg">
              <div className={`w-2 h-2 rounded-full mt-1.5 ${event.severity === 'error' ? 'bg-red-500' : event.severity === 'warning' ? 'bg-yellow-500' : 'bg-blue-500'}`} />
              <div className="flex-1">
                <p className="text-sm text-white">{event.event}</p>
                <p className="text-xs text-slate-500 mt-1">{event.timestamp}</p>
              </div>
            </motion.div>)}
        </div>
      </motion.div>
    </div>;
}
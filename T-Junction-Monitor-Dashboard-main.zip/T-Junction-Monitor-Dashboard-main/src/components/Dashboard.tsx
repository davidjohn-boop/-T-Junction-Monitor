import React from 'react';
import { RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { TrafficLight } from './TrafficLight';
import { TrafficData } from '../types/traffic';
interface DashboardProps {
  data: TrafficData | null;
  loading: boolean;
  onRefresh: () => void;
  isConnected: boolean;
}
export function Dashboard({
  data,
  loading,
  onRefresh,
  isConnected
}: DashboardProps) {
  return <div className="space-y-6">
      <div className="flex items-center justify-between">
        <motion.h2 initial={{
        opacity: 0,
        x: -20
      }} animate={{
        opacity: 1,
        x: 0
      }} className="text-2xl font-bold text-white">
          Live Traffic Monitor
        </motion.h2>
        <motion.button initial={{
        opacity: 0,
        x: 20
      }} animate={{
        opacity: 1,
        x: 0
      }} whileHover={{
        scale: 1.05
      }} whileTap={{
        scale: 0.95
      }} onClick={onRefresh} disabled={loading || !isConnected} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed text-white rounded-lg transition-all duration-200 glow-blue">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          Refresh Data
        </motion.button>
      </div>

      {!isConnected ? <motion.div initial={{
      opacity: 0,
      scale: 0.95
    }} animate={{
      opacity: 1,
      scale: 1
    }} className="glass-strong rounded-xl p-12 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <RefreshCw className="w-8 h-8 text-blue-400" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Not Connected
            </h3>
            <p className="text-slate-400">
              Please connect to the device in Settings to start monitoring
              traffic data.
            </p>
          </div>
        </motion.div> : <motion.div initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      duration: 0.5
    }} className="glass-strong rounded-xl p-8">
          <div className="flex flex-col items-center gap-8">
            <h3 className="text-xl font-semibold text-white">
              T-Junction Traffic Control
            </h3>

            <div className="relative w-full max-w-2xl">
              {/* Main Road (Horizontal) */}
              <div className="flex items-center justify-center gap-8">
                <div className="flex-1 h-16 glass rounded-l-xl flex items-center justify-center">
                  <span className="text-slate-400 font-medium">
                    ← Main Road
                  </span>
                </div>

                <div className="flex flex-col items-center gap-4">
                  <TrafficLight state={data?.mainLight || 'red'} label="Main" />
                </div>

                <div className="flex-1 h-16 glass rounded-r-xl flex items-center justify-center">
                  <span className="text-slate-400 font-medium">
                    Main Road →
                  </span>
                </div>
              </div>

              {/* Side Road (Vertical) */}
              <div className="absolute left-1/2 -translate-x-1/2 top-full mt-4 flex flex-col items-center gap-4">
                <TrafficLight state={data?.sideLight || 'red'} label="Side" />
                <div className="w-16 h-32 glass rounded-b-xl flex items-center justify-center">
                  <span className="text-slate-400 font-medium rotate-90 whitespace-nowrap">
                    Side Road ↓
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full mt-32">
              <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.2
          }} className="glass rounded-xl p-6 text-center">
                <p className="text-slate-400 text-sm mb-2">Main Road Queue</p>
                <p className="text-4xl font-bold text-blue-400">
                  {data?.mainQueue || 0}
                </p>
                <p className="text-slate-500 text-sm mt-1">vehicles</p>
              </motion.div>

              <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.3
          }} className="glass rounded-xl p-6 text-center">
                <p className="text-slate-400 text-sm mb-2">Side Road Queue</p>
                <p className="text-4xl font-bold text-cyan-400">
                  {data?.sideQueue || 0}
                </p>
                <p className="text-slate-500 text-sm mt-1">vehicles</p>
              </motion.div>

              <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            delay: 0.4
          }} className="glass rounded-xl p-6 text-center">
                <p className="text-slate-400 text-sm mb-2">
                  Total Vehicles Today
                </p>
                <p className="text-4xl font-bold text-blue-500">
                  {data?.totalVehiclesToday || 0}
                </p>
                <p className="text-slate-500 text-sm mt-1">passed</p>
              </motion.div>
            </div>
          </div>
        </motion.div>}

      {data?.timestamp && isConnected && <motion.p initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} transition={{
      delay: 0.5
    }} className="text-sm text-slate-500 text-center">
          Last updated: {new Date(data.timestamp).toLocaleString()}
        </motion.p>}
    </div>;
}
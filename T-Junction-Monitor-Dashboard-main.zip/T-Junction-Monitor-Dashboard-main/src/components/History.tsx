import React from 'react';
import { motion } from 'framer-motion';
import { HistoryEntry } from '../types/traffic';
interface HistoryProps {
  data: HistoryEntry[];
  isConnected: boolean;
}
export function History({
  data,
  isConnected
}: HistoryProps) {
  if (!isConnected) {
    return <motion.div initial={{
      opacity: 0,
      scale: 0.95
    }} animate={{
      opacity: 1,
      scale: 1
    }} className="glass-strong rounded-xl p-12 text-center">
        <div className="max-w-md mx-auto">
          <div className="w-16 h-16 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-white mb-2">
            No History Available
          </h3>
          <p className="text-slate-400">
            Connect to the device to view traffic history records.
          </p>
        </div>
      </motion.div>;
  }
  return <div className="space-y-6">
      <motion.h2 initial={{
      opacity: 0,
      x: -20
    }} animate={{
      opacity: 1,
      x: 0
    }} className="text-2xl font-bold text-white">
        Traffic History
      </motion.h2>

      <motion.div initial={{
      opacity: 0,
      y: 20
    }} animate={{
      opacity: 1,
      y: 0
    }} transition={{
      delay: 0.1
    }} className="glass-strong rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-800/50 border-b border-slate-700/50">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Time
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Main Queue
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-300">
                  Side Queue
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/30">
              {data.length === 0 ? <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-slate-500">
                    No history data available
                  </td>
                </tr> : data.map((entry, index) => <motion.tr key={index} initial={{
              opacity: 0,
              x: -20
            }} animate={{
              opacity: 1,
              x: 0
            }} transition={{
              delay: 0.2 + index * 0.03
            }} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4 text-sm text-slate-300">
                      {entry.time}
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className="inline-flex items-center px-3 py-1 rounded-full bg-blue-500/20 text-blue-400 font-medium">
                        {entry.mainQueue}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <span className="inline-flex items-center px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-400 font-medium">
                        {entry.sideQueue}
                      </span>
                    </td>
                  </motion.tr>)}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>;
}
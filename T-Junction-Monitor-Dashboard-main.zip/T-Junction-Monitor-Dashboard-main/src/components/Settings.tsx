import React, { useEffect, useState } from 'react';
import { Wifi, WifiOff, Clock, Power, Save, Trash2, Shield, ShieldOff, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { ConnectionStatus, WiFiSettings } from '../types/traffic';
import { NetworkScanner } from './NetworkScanner';
import { MapView } from './MapView';
interface SettingsProps {
  status: ConnectionStatus | null;
  onConnect: (settings: WiFiSettings, rememberSettings: boolean) => Promise<boolean>;
  onDisconnect: () => void;
  onClearSettings: () => void;
  loading: boolean;
  isConnected: boolean;
  savedSettings: WiFiSettings | null;
  serverAvailable: boolean;
}
export function Settings({
  status,
  onConnect,
  onDisconnect,
  onClearSettings,
  loading,
  isConnected,
  savedSettings,
  serverAvailable
}: SettingsProps) {
  const [formData, setFormData] = useState<WiFiSettings>({
    ssid: '',
    password: '',
    deviceIp: '192.168.1.101',
    port: '8080'
  });
  const [rememberSettings, setRememberSettings] = useState(false);
  const [requiresPassword, setRequiresPassword] = useState(true);
  // Load saved settings
  useEffect(() => {
    if (savedSettings) {
      setFormData(savedSettings);
      setRequiresPassword(!!savedSettings.password);
    }
  }, [savedSettings]);
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const settingsToSend = requiresPassword ? formData : {
      ...formData,
      password: ''
    };
    await onConnect(settingsToSend, rememberSettings);
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };
  const handleSelectNetwork = (ssid: string, secured: boolean) => {
    setFormData(prev => ({
      ...prev,
      ssid
    }));
    setRequiresPassword(secured);
  };
  return <div className="space-y-6">
      {/* Server Status Warning */}
      {serverAvailable === false && <motion.div initial={{
      opacity: 0,
      y: -10
    }} animate={{
      opacity: 1,
      y: 0
    }} className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <h4 className="text-red-400 font-medium mb-1">
                Server Not Running
              </h4>
              <p className="text-sm text-slate-400 mb-3">
                The Express server is not running. Start it first before
                connecting:
              </p>
              <div className="bg-slate-900/50 rounded p-3 font-mono text-xs text-slate-300">
                <div>cd server</div>
                <div>npm install</div>
                <div>node index.js</div>
              </div>
              <p className="text-xs text-slate-500 mt-2">
                The server should start on http://localhost:3001
              </p>
            </div>
          </div>
        </motion.div>}

      <motion.div initial={{
      opacity: 0,
      x: -20
    }} animate={{
      opacity: 1,
      x: 0
    }} className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Device Settings</h2>
        {savedSettings && !isConnected && <motion.button whileHover={{
        scale: 1.05
      }} whileTap={{
        scale: 0.95
      }} onClick={onClearSettings} className="flex items-center gap-2 px-4 py-2 glass rounded-lg text-red-400 hover:text-red-300 transition-colors">
            <Trash2 className="w-4 h-4" />
            Clear Saved
          </motion.button>}
      </motion.div>

      {savedSettings && !isConnected && <motion.div initial={{
      opacity: 0,
      y: -10
    }} animate={{
      opacity: 1,
      y: 0
    }} className="glass rounded-lg p-4 border border-blue-500/30">
          <div className="flex items-center gap-3">
            <Save className="w-5 h-5 text-blue-400" />
            <div>
              <p className="text-sm font-medium text-white">Saved Connection</p>
              <p className="text-xs text-slate-400">
                {savedSettings.ssid} • {savedSettings.deviceIp}:
                {savedSettings.port}
              </p>
            </div>
          </div>
        </motion.div>}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Wi-Fi Connection Form */}
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        delay: 0.1
      }} className="glass-strong rounded-xl p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-white">
              Wi-Fi Connection
            </h3>
            {requiresPassword ? <div className="flex items-center gap-2 text-xs text-slate-400">
                <Shield className="w-4 h-4" />
                Secured
              </div> : <div className="flex items-center gap-2 text-xs text-green-400">
                <ShieldOff className="w-4 h-4" />
                Open Network
              </div>}
          </div>

          {/* Network Scanner */}
          {!isConnected && <NetworkScanner onSelectNetwork={handleSelectNetwork} selectedSSID={formData.ssid} />}

          {/* Connection Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="ssid" className="block text-sm font-medium text-slate-300 mb-2">
                Network SSID *
              </label>
              <input type="text" id="ssid" name="ssid" value={formData.ssid} onChange={handleChange} disabled={isConnected} className="w-full px-4 py-2.5 glass rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all" placeholder="Enter network name" required />
            </div>

            {requiresPassword && <div>
                <label htmlFor="password" className="block text-sm font-medium text-slate-300 mb-2">
                  Password {!requiresPassword && '(Optional)'}
                </label>
                <input type="password" id="password" name="password" value={formData.password} onChange={handleChange} disabled={isConnected} className="w-full px-4 py-2.5 glass rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all" placeholder={requiresPassword ? 'Enter password' : 'Leave empty for open network'} required={requiresPassword} />
              </div>}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="deviceIp" className="block text-sm font-medium text-slate-300 mb-2">
                  Device IP *
                </label>
                <input type="text" id="deviceIp" name="deviceIp" value={formData.deviceIp} onChange={handleChange} disabled={isConnected} className="w-full px-4 py-2.5 glass rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all" required />
              </div>

              <div>
                <label htmlFor="port" className="block text-sm font-medium text-slate-300 mb-2">
                  Port *
                </label>
                <input type="text" id="port" name="port" value={formData.port} onChange={handleChange} disabled={isConnected} className="w-full px-4 py-2.5 glass rounded-lg text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all" required />
              </div>
            </div>

            {!isConnected && <label className="flex items-center gap-3 p-3 glass rounded-lg cursor-pointer hover:bg-slate-800/50 transition-colors">
                <input type="checkbox" checked={rememberSettings} onChange={e => setRememberSettings(e.target.checked)} className="w-4 h-4 rounded border-slate-600 text-blue-600 focus:ring-blue-500 focus:ring-offset-0" />
                <div className="flex items-center gap-2 text-sm text-slate-300">
                  <Save className="w-4 h-4" />
                  Remember these settings
                </div>
              </label>}

            {!isConnected ? <motion.button whileHover={{
            scale: 1.02
          }} whileTap={{
            scale: 0.98
          }} type="submit" disabled={loading} className="w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-700 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-all duration-200 glow-blue flex items-center justify-center gap-2">
                <Wifi className="w-5 h-5" />
                {loading ? 'Connecting...' : 'Connect to Network'}
              </motion.button> : <motion.button whileHover={{
            scale: 1.02
          }} whileTap={{
            scale: 0.98
          }} type="button" onClick={onDisconnect} className="w-full px-4 py-3 bg-red-600 hover:bg-red-700 text-white font-medium rounded-lg transition-all duration-200 flex items-center justify-center gap-2">
                <Power className="w-5 h-5" />
                Disconnect
              </motion.button>}
          </form>
        </motion.div>

        {/* Status and Map Column */}
        <div className="space-y-6">
          {/* Connection Status */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.2
        }} className="glass-strong rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">
              Connection Status
            </h3>

            <div className="space-y-4">
              <motion.div initial={{
              scale: 0.9
            }} animate={{
              scale: 1
            }} transition={{
              delay: 0.3
            }} className={`flex items-center gap-3 p-4 rounded-lg ${isConnected ? 'bg-blue-500/20 glow-blue' : 'glass'}`}>
                {isConnected ? <>
                    <motion.div animate={{
                  scale: [1, 1.2, 1]
                }} transition={{
                  duration: 2,
                  repeat: Infinity
                }}>
                      <Wifi className="w-6 h-6 text-blue-400" />
                    </motion.div>
                    <div>
                      <p className="text-white font-medium">Connected</p>
                      <p className="text-sm text-slate-400">
                        Device is online and streaming data
                      </p>
                    </div>
                  </> : <>
                    <WifiOff className="w-6 h-6 text-slate-500" />
                    <div>
                      <p className="text-white font-medium">Not Connected</p>
                      <p className="text-sm text-slate-400">
                        Select a network to connect
                      </p>
                    </div>
                  </>}
              </motion.div>

              {isConnected && status && <>
                  <motion.div initial={{
                opacity: 0,
                y: 10
              }} animate={{
                opacity: 1,
                y: 0
              }} transition={{
                delay: 0.4
              }} className="flex items-center gap-3 p-4 glass rounded-lg">
                    <Clock className="w-6 h-6 text-blue-400" />
                    <div>
                      <p className="text-white font-medium">Uptime</p>
                      <p className="text-sm text-slate-400">{status.uptime}</p>
                    </div>
                  </motion.div>

                  <motion.div initial={{
                opacity: 0,
                y: 10
              }} animate={{
                opacity: 1,
                y: 0
              }} transition={{
                delay: 0.5
              }} className="p-4 glass rounded-lg">
                    <p className="text-sm text-slate-400 mb-1">Last Update</p>
                    <p className="text-white font-medium">
                      {status.lastUpdate}
                    </p>
                  </motion.div>
                </>}
            </div>
          </motion.div>

          {/* Map View */}
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: 0.3
        }} className="glass-strong rounded-xl p-6">
            <MapView />
          </motion.div>
        </div>
      </div>
    </div>;
}
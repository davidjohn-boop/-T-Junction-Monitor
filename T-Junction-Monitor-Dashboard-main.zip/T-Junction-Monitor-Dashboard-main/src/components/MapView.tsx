import React, { useState } from 'react';
import { MapPin, Navigation, ZoomIn, ZoomOut } from 'lucide-react';
import { motion } from 'framer-motion';
interface MapViewProps {
  junctionLocation?: {
    lat: number;
    lng: number;
    name: string;
  };
}
export function MapView({
  junctionLocation = {
    lat: 40.7128,
    lng: -74.006,
    name: 'T-Junction Monitor'
  }
}: MapViewProps) {
  const [zoom, setZoom] = useState(15);
  return <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-slate-300">
          Junction Location
        </h4>
        <div className="flex items-center gap-2">
          <motion.button whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }} onClick={() => setZoom(Math.min(zoom + 1, 20))} className="p-2 glass rounded-lg hover:bg-slate-800/50 transition-colors">
            <ZoomIn className="w-4 h-4 text-slate-400" />
          </motion.button>
          <motion.button whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }} onClick={() => setZoom(Math.max(zoom - 1, 10))} className="p-2 glass rounded-lg hover:bg-slate-800/50 transition-colors">
            <ZoomOut className="w-4 h-4 text-slate-400" />
          </motion.button>
        </div>
      </div>

      <div className="relative glass-strong rounded-xl overflow-hidden h-64">
        {/* Map placeholder with grid */}
        <div className="absolute inset-0 bg-slate-900">
          <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: `
                linear-gradient(to right, rgb(59, 130, 246) 1px, transparent 1px),
                linear-gradient(to bottom, rgb(59, 130, 246) 1px, transparent 1px)
              `,
          backgroundSize: '40px 40px'
        }} />
        </div>

        {/* Junction marker */}
        <motion.div initial={{
        scale: 0
      }} animate={{
        scale: 1
      }} transition={{
        delay: 0.2,
        type: 'spring'
      }} className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="relative">
            <motion.div animate={{
            scale: [1, 1.2, 1]
          }} transition={{
            duration: 2,
            repeat: Infinity
          }} className="absolute inset-0 bg-blue-500/30 rounded-full blur-xl" />
            <div className="relative w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center glow-blue-strong">
              <MapPin className="w-6 h-6 text-white" />
            </div>
          </div>
        </motion.div>

        {/* Traffic flow indicators */}
        <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} transition={{
        delay: 0.4
      }} className="absolute top-1/2 left-1/4 -translate-y-1/2">
          <div className="flex items-center gap-2 glass px-3 py-2 rounded-lg">
            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
            <span className="text-xs text-slate-300">Main Road</span>
          </div>
        </motion.div>

        <motion.div initial={{
        opacity: 0
      }} animate={{
        opacity: 1
      }} transition={{
        delay: 0.5
      }} className="absolute top-1/4 left-1/2 -translate-x-1/2">
          <div className="flex items-center gap-2 glass px-3 py-2 rounded-lg">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-xs text-slate-300">Side Road</span>
          </div>
        </motion.div>

        {/* Compass */}
        <div className="absolute top-4 right-4 glass p-2 rounded-lg">
          <Navigation className="w-5 h-5 text-blue-400" />
        </div>

        {/* Coordinates */}
        <div className="absolute bottom-4 left-4 glass px-3 py-2 rounded-lg">
          <p className="text-xs text-slate-400">
            {junctionLocation.lat.toFixed(4)}°,{' '}
            {junctionLocation.lng.toFixed(4)}°
          </p>
        </div>
      </div>

      <div className="glass rounded-lg p-4">
        <div className="flex items-start gap-3">
          <MapPin className="w-5 h-5 text-blue-400 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-white">
              {junctionLocation.name}
            </p>
            <p className="text-xs text-slate-500 mt-1">
              Monitoring active traffic flow at this intersection
            </p>
          </div>
        </div>
      </div>
    </div>;
}
import React, { useEffect } from 'react';
import { Wifi, Lock, Unlock, RefreshCw, Info } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNetworkScanner, WiFiNetwork } from '../hooks/useNetworkScanner';
interface NetworkScannerProps {
  onSelectNetwork: (ssid: string, secured: boolean) => void;
  selectedSSID?: string;
}
export function NetworkScanner({
  onSelectNetwork,
  selectedSSID
}: NetworkScannerProps) {
  const {
    networks,
    scanning,
    scanNetworks
  } = useNetworkScanner();
  useEffect(() => {
    scanNetworks();
  }, [scanNetworks]);
  const getSignalColor = (signal: number) => {
    if (signal >= 80) return 'text-blue-400';
    if (signal >= 60) return 'text-cyan-400';
    if (signal >= 40) return 'text-yellow-400';
    return 'text-orange-400';
  };
  const getSignalBars = (signal: number) => {
    const bars = Math.ceil(signal / 100 * 4);
    return <div className="flex items-end gap-0.5 h-4">
        {[1, 2, 3, 4].map(bar => <div key={bar} className={`w-1 rounded-sm transition-all ${bar <= bars ? 'bg-current' : 'bg-slate-700'}`} style={{
        height: `${bar * 25}%`
      }} />)}
      </div>;
  };
  return <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-slate-300">
          Available Networks
        </h4>
        <motion.button whileHover={{
        scale: 1.05
      }} whileTap={{
        scale: 0.95
      }} onClick={scanNetworks} disabled={scanning} className="flex items-center gap-2 px-3 py-1.5 glass rounded-lg text-sm text-blue-400 hover:text-blue-300 transition-colors disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${scanning ? 'animate-spin' : ''}`} />
          Scan
        </motion.button>
      </div>

      <motion.div initial={{
      opacity: 0,
      y: -10
    }} animate={{
      opacity: 1,
      y: 0
    }} className="flex items-start gap-2 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
        <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
        <p className="text-xs text-slate-400">
          <span className="text-blue-400 font-medium">Demo Mode:</span> These
          are simulated networks. Enter your actual network name manually below
          to connect.
        </p>
      </motion.div>

      <div className="space-y-2 max-h-64 overflow-y-auto">
        {networks.map((network, index) => <motion.button key={network.ssid} initial={{
        opacity: 0,
        x: -20
      }} animate={{
        opacity: 1,
        x: 0
      }} transition={{
        delay: index * 0.05
      }} onClick={() => onSelectNetwork(network.ssid, network.secured)} className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all ${selectedSSID === network.ssid ? 'glass-strong glow-blue border border-blue-500/50' : 'glass hover:bg-slate-800/50'}`}>
            <div className={getSignalColor(network.signal)}>
              {getSignalBars(network.signal)}
            </div>

            <div className="flex-1 text-left">
              <div className="flex items-center gap-2">
                <span className="text-white font-medium">{network.ssid}</span>
                {network.secured ? <Lock className="w-3 h-3 text-slate-500" /> : <Unlock className="w-3 h-3 text-yellow-500" />}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>Channel {network.channel}</span>
                <span>•</span>
                <span>{network.signal}%</span>
              </div>
            </div>

            <Wifi className={`w-5 h-5 ${getSignalColor(network.signal)}`} />
          </motion.button>)}
      </div>

      {networks.length === 0 && !scanning && <div className="text-center py-8 text-slate-500">
          <Wifi className="w-8 h-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">No networks found</p>
        </div>}
    </div>;
}